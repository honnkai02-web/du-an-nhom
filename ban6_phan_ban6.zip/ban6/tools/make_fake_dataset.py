"""
Sinh DỮ LIỆU GIẢ có cấu trúc giống dataset_pe.csv của Bạn 2 (để Bạn 6 tự test).
Chỉ dùng để thử code - KHÔNG dùng để báo cáo kết quả trong Word/PowerPoint.

    python tools/make_fake_dataset.py --n 1200 --malware-ratio 0.08 --difficulty 1.0 --out data/dataset_pe_fake.csv

--malware-ratio : tỉ lệ mã độc (0.08 = lệch mạnh 92% sạch / 8% độc)
--difficulty    : 0.5 dễ tách | 1.0 vừa | 2.0 khó (hai lớp chồng lấn nhiều -> không ra 100%)
Cột tạo ra: filename, + 10 đặc trưng PE + label (0 sạch / 1 độc), cùng quy ước với nhóm.
"""
import argparse
import os

import numpy as np
import pandas as pd

FEATURES = ["file_size", "num_sections", "avg_section_entropy", "max_section_entropy", "num_imports",
            "num_suspicious_apis", "image_size", "entry_point", "num_exports", "has_packed_section"]


def make_fake_pe_dataset(n=1200, malware_ratio=0.08, difficulty=1.0, seed=0) -> pd.DataFrame:
    rng = np.random.RandomState(seed)
    n_mal = max(2, int(round(n * malware_ratio)))
    y = np.array([1] * n_mal + [0] * (n - n_mal))
    rng.shuffle(y)
    d = difficulty
    mal = y == 1
    # độ lệch giữa 2 lớp co giãn theo difficulty (d lớn -> hai lớp gần nhau hơn)
    shift = 1.0 / d
    num_sections = np.clip(np.round(rng.normal(4.5 + 1.2 * shift * mal, 1.3 * d)), 1, 12)
    avg_ent = np.clip(rng.normal(5.4 + 1.1 * shift * mal, 0.7 * d), 0.5, 7.99)
    max_ent = np.clip(avg_ent + np.abs(rng.normal(0.8, 0.5, n)) + 0.4 * shift * mal, 0.5, 8.0)
    num_imports = np.clip(np.round(rng.lognormal(4.0 - 0.8 * shift * mal, 0.7 * d)), 1, 900)
    sus = np.clip(np.round(rng.poisson(1.0 + 4.0 * shift * mal * (1 if d <= 1 else 1 / d**0.5)) +
                           rng.normal(0, d, n)), 0, 40)
    file_size = np.clip(rng.lognormal(12.5 - 0.3 * mal, 1.1, n), 2_000, 60_000_000).round()
    image_size = np.clip(file_size * rng.uniform(1.0, 2.2, n), 4_096, 120_000_000).round()
    entry = np.clip(rng.lognormal(8.0 + 0.6 * shift * mal, 1.0, n), 256, 5_000_000).round()
    exports = np.clip(np.round(rng.exponential(2.0 + 3 * (1 - mal), n)), 0, 300)
    packed = ((max_ent > 7.0) | (rng.rand(n) < 0.02 + 0.25 * shift * mal / 1.5)).astype(int)
    df = pd.DataFrame({"filename": [f"fake_{i:05d}.exe" for i in range(n)], "file_size": file_size,
                       "num_sections": num_sections, "avg_section_entropy": avg_ent.round(4),
                       "max_section_entropy": max_ent.round(4), "num_imports": num_imports,
                       "num_suspicious_apis": sus, "image_size": image_size, "entry_point": entry,
                       "num_exports": exports, "has_packed_section": packed, "label": y})
    return df


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=1200)
    ap.add_argument("--malware-ratio", type=float, default=0.08)
    ap.add_argument("--difficulty", type=float, default=1.0)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", default="data/dataset_pe_fake.csv")
    a = ap.parse_args()
    df = make_fake_pe_dataset(a.n, a.malware_ratio, a.difficulty, a.seed)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    df.to_csv(a.out, index=False)
    print(f"Đã tạo {a.out}: {len(df)} dòng | sạch={int((df.label == 0).sum())} độc={int((df.label == 1).sum())}")


if __name__ == "__main__":
    main()
