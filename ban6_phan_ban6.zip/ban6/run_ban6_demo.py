"""
CHẠY THỬ PHẦN BẠN 6 CHỈ VỚI 1 LỆNH (dữ liệu giả, không cần ai khác):

    python run_ban6_demo.py                      # dữ liệu giả lệch 92/8
    python run_ban6_demo.py --csv dataset_pe.csv # khi có dữ liệu thật của Bạn 2 (cột label 0/1)
    python run_ban6_demo.py --csv dataset_pe.csv dataset_ngram_features.csv   # ghép PE + N-gram theo filename
"""
import argparse
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

from modules.model_optimizer import load_bundle, predict_bundle, run_pipeline  # noqa: E402
from tools.make_fake_dataset import make_fake_pe_dataset  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", nargs="*", help="Bỏ trống = tự sinh dữ liệu giả")
    ap.add_argument("--malware-ratio", type=float, default=0.08)
    ap.add_argument("--difficulty", type=float, default=1.0)
    ap.add_argument("--n-iter", type=int, default=15)
    ap.add_argument("--target-fpr", type=float, default=0.01)
    a = ap.parse_args()

    csvs = a.csv
    if not csvs:
        os.makedirs(os.path.join(ROOT, "data"), exist_ok=True)
        path = os.path.join(ROOT, "data", "dataset_pe_fake.csv")
        make_fake_pe_dataset(1200, a.malware_ratio, a.difficulty).to_csv(path, index=False)
        csvs = [path]
        print(f"(Dùng dữ liệu GIẢ: {path})\n")

    res = run_pipeline(csvs, out_dir=ROOT, n_iter=a.n_iter, target_fpr=a.target_fpr)
    m = res["metrics_final"]
    print("\n===== KẾT QUẢ TRÊN TẬP TEST =====")
    print(f"Accuracy {m['accuracy']:.2%} | Recall {m['recall']:.2%} | FPR {m['fpr']:.2%} | "
          f"Precision {m['precision']:.2%} | AUC {m['roc_auc']:.4f}")
    print(f"TN={m['tn']} FP={m['fp']} FN={m['fn']} TP={m['tp']}")

    # Minh họa đúng cách Bạn 1 sẽ gọi sau này
    import pandas as pd
    b = load_bundle(res["saved"]["model"])
    sample = pd.read_csv(csvs[0]).head(3)
    print("\nThử dự đoán 3 dòng đầu bằng predict_bundle():")
    print(pd.concat([sample[["filename"]].reset_index(drop=True) if "filename" in sample else sample.iloc[:, :0],
                     predict_bundle(b, sample).reset_index(drop=True)], axis=1).to_string(index=False))
    print(f"\nBáo cáo: {res['saved']['report_md']}\nBiểu đồ: {res['saved'].get('plot')}")


if __name__ == "__main__":
    main()
