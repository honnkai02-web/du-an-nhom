"""
BẠN 6 - Tối ưu mô hình, đo đạc đánh giá.

Module độc lập: chỉ cần một (hoặc nhiều) file CSV có cột nhãn `label`
(0 = file sạch, 1 = mã độc; cũng chấp nhận chữ "clean"/"malware"...).
Không phụ thuộc code của Bạn 2/3/4/5 -> có thể test bằng dữ liệu giả
và về sau thay bằng dữ liệu thật mà không phải sửa code.

Chức năng:
  1. Xử lý mất cân bằng lớp : none | class_weight | oversample | smote | undersample
  2. Hyperparameter tuning  : random search + Stratified K-Fold (resample TRONG từng fold, không rò rỉ)
  3. Chọn ngưỡng quyết định : cực đại Recall với điều kiện FPR <= target_fpr
  4. Đo đạc                 : Accuracy, Precision, Recall, F1, FPR, ROC-AUC, ma trận nhầm lẫn
  5. Xuất                   : models/ban6_best_model.joblib, reports/ban6_*.{json,csv,md,png}

API cho Bạn 1 (tích hợp):
    from modules.model_optimizer import load_bundle, predict_bundle
    bundle = load_bundle("models/ban6_best_model.joblib")
    out = predict_bundle(bundle, feature_dataframe)   # -> DataFrame: proba, prediction, verdict
"""
from __future__ import annotations

import json
import os
import warnings
from typing import Dict, Iterable, List, Optional, Sequence, Tuple, Union

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.metrics import confusion_matrix, roc_auc_score, roc_curve
from sklearn.model_selection import ParameterSampler, StratifiedKFold, train_test_split
from sklearn.neighbors import NearestNeighbors
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

try:  # XGBoost là tùy chọn: nếu máy chưa cài thì tự dùng mô hình thay thế của sklearn
    from xgboost import XGBClassifier  # type: ignore

    HAS_XGB = True
except Exception:  # pragma: no cover
    XGBClassifier = None  # type: ignore
    HAS_XGB = False

STRATEGIES = ("none", "class_weight", "oversample", "smote", "undersample")
ID_COLUMNS = {"filename", "file", "name", "md5", "sha256", "sha1", "hash", "path", "family"}
LABEL_CANDIDATES = ("label", "Label", "class", "Class", "is_malware", "malware", "target")
_POS_WORDS = {"1", "malware", "malicious", "mal", "virus", "bad", "độc", "doc", "true"}
_NEG_WORDS = {"0", "clean", "benign", "good", "safe", "sạch", "sach", "false"}


# ----------------------------------------------------------------------------
# 1. NẠP DỮ LIỆU
# ----------------------------------------------------------------------------
def _to_binary_label(series: pd.Series) -> pd.Series:
    def conv(v):
        s = str(v).strip().lower()
        if s in _POS_WORDS or s == "1.0":
            return 1
        if s in _NEG_WORDS or s == "0.0":
            return 0
        raise ValueError(f"Nhãn không hiểu được: {v!r} (chỉ nhận 0/1 hoặc clean/malware)")

    return series.map(conv).astype(int)


def load_dataset(
    csv_paths: Union[str, Sequence[str]], label_col: Optional[str] = None
) -> Tuple[pd.DataFrame, pd.Series, List[str]]:
    """Đọc 1 hoặc nhiều CSV (vd dataset_pe.csv của Bạn 2 + dataset_ngram_features.csv của Bạn 3).

    Nhiều file sẽ được ghép theo cột `filename` (inner join). Trả về (X, y, tên_file).
    Cột chữ (filename, md5...) bị bỏ khỏi X; cột số được giữ lại, ô trống -> 0.
    """
    if isinstance(csv_paths, str):
        csv_paths = [csv_paths]
    frames = [pd.read_csv(p) for p in csv_paths]
    if len(frames) == 1:
        df = frames[0]
    else:
        if not all("filename" in f.columns for f in frames):
            raise ValueError("Muốn ghép nhiều CSV thì mỗi file phải có cột 'filename'")
        df = frames[0]
        for i, f in enumerate(frames[1:], 1):
            lab = [c for c in f.columns if c in LABEL_CANDIDATES]
            df = df.merge(f.drop(columns=lab), on="filename", how="inner", suffixes=("", f"_f{i}"))
        if df.empty:
            raise ValueError("Ghép CSV xong không còn dòng nào (tên file không khớp?)")

    if label_col is None:
        label_col = next((c for c in LABEL_CANDIDATES if c in df.columns), None)
    if label_col is None or label_col not in df.columns:
        raise ValueError(f"Không tìm thấy cột nhãn. Các cột hiện có: {list(df.columns)[:15]}...")

    y = _to_binary_label(df[label_col])
    names = df["filename"].astype(str).tolist() if "filename" in df.columns else [str(i) for i in df.index]
    drop = {label_col} | {c for c in df.columns if c.lower() in ID_COLUMNS}
    X = df.drop(columns=list(drop))
    X = X.apply(pd.to_numeric, errors="coerce")
    X = X.dropna(axis=1, how="all").fillna(0.0).astype(float)
    if X.shape[1] == 0:
        raise ValueError("Không có cột đặc trưng dạng số nào")
    if y.nunique() < 2:
        raise ValueError("Dataset chỉ có 1 lớp nhãn - không thể huấn luyện")
    return X, y, names


# ----------------------------------------------------------------------------
# 2. XỬ LÝ MẤT CÂN BẰNG LỚP
# ----------------------------------------------------------------------------
def _smote(X: np.ndarray, y: np.ndarray, rng: np.random.RandomState, k: int = 5):
    """SMOTE tự cài (không cần thư viện imbalanced-learn): nội suy giữa mẫu thiểu số và láng giềng."""
    classes, counts = np.unique(y, return_counts=True)
    minority, majority = classes[counts.argmin()], classes[counts.argmax()]
    Xmin = X[y == minority]
    need = int(counts.max() - counts.min())
    if need == 0:
        return X, y
    if len(Xmin) < 2:  # quá ít mẫu để nội suy -> nhân bản
        idx = rng.randint(0, len(Xmin), need)
        return np.vstack([X, Xmin[idx]]), np.concatenate([y, np.full(need, minority)])
    k = min(k, len(Xmin) - 1)
    nn = NearestNeighbors(n_neighbors=k + 1).fit(Xmin)
    neigh = nn.kneighbors(Xmin, return_distance=False)[:, 1:]
    base = rng.randint(0, len(Xmin), need)
    pick = neigh[base, rng.randint(0, k, need)]
    gap = rng.rand(need, 1)
    synth = Xmin[base] + gap * (Xmin[pick] - Xmin[base])
    return np.vstack([X, synth]), np.concatenate([y, np.full(need, minority)])


def resample(X: np.ndarray, y: np.ndarray, strategy: str, seed: int = 42):
    """Chỉ gọi trên tập TRAIN. 'none' và 'class_weight' không đổi dữ liệu."""
    if strategy not in STRATEGIES:
        raise ValueError(f"strategy phải thuộc {STRATEGIES}")
    rng = np.random.RandomState(seed)
    X, y = np.asarray(X, float), np.asarray(y)
    if strategy in ("none", "class_weight"):
        return X, y
    classes, counts = np.unique(y, return_counts=True)
    mi, ma = classes[counts.argmin()], classes[counts.argmax()]
    if strategy == "oversample":
        idx_min = np.where(y == mi)[0]
        extra = rng.choice(idx_min, int(counts.max() - counts.min()), replace=True)
        keep = np.concatenate([np.arange(len(y)), extra])
        return X[keep], y[keep]
    if strategy == "undersample":
        idx_ma = rng.choice(np.where(y == ma)[0], int(counts.min()), replace=False)
        keep = np.concatenate([np.where(y == mi)[0], idx_ma])
        rng.shuffle(keep)
        return X[keep], y[keep]
    return _smote(X, y, rng)  # smote


# ----------------------------------------------------------------------------
# 3. MÔ HÌNH + KHÔNG GIAN THAM SỐ
# ----------------------------------------------------------------------------
def available_models() -> List[str]:
    return (["xgboost"] if HAS_XGB else []) + ["random_forest", "hist_gb"]


def resolve_model(kind: str) -> str:
    if kind == "auto":
        return "xgboost" if HAS_XGB else "hist_gb"
    if kind == "xgboost" and not HAS_XGB:
        warnings.warn("Chưa cài xgboost -> dùng hist_gb (cùng họ Gradient Boosting)")
        return "hist_gb"
    if kind not in ("xgboost", "random_forest", "hist_gb"):
        raise ValueError("model phải là auto | xgboost | random_forest | hist_gb")
    return kind


def param_space(kind: str) -> Dict[str, list]:
    if kind == "xgboost":
        return {
            "n_estimators": [100, 200, 300, 500],
            "max_depth": [3, 4, 6, 8],
            "learning_rate": [0.03, 0.05, 0.1, 0.2],
            "subsample": [0.7, 0.85, 1.0],
            "colsample_bytree": [0.6, 0.8, 1.0],
            "reg_lambda": [0.5, 1.0, 3.0, 10.0],
            "min_child_weight": [1, 3, 5],
        }
    if kind == "random_forest":
        return {
            "n_estimators": [100, 200, 400],
            "max_depth": [None, 6, 12, 20],
            "min_samples_leaf": [1, 2, 4],
            "max_features": ["sqrt", "log2", 0.5],
        }
    return {  # hist_gb
        "max_iter": [100, 200, 300],
        "max_depth": [None, 3, 5, 8],
        "learning_rate": [0.03, 0.05, 0.1, 0.2],
        "min_samples_leaf": [5, 10, 20],
        "l2_regularization": [0.0, 0.5, 1.0, 5.0],
    }


def make_estimator(kind: str, params: dict, strategy: str, y_train: np.ndarray, seed: int = 42):
    y_train = np.asarray(y_train)
    n_pos, n_neg = int((y_train == 1).sum()), int((y_train == 0).sum())
    cw = strategy == "class_weight"
    if kind == "xgboost":
        spw = (n_neg / max(n_pos, 1)) if cw else 1.0
        return XGBClassifier(
            **params, scale_pos_weight=spw, eval_metric="logloss", random_state=seed, n_jobs=1, verbosity=0
        )
    if kind == "random_forest":
        return RandomForestClassifier(
            **params, class_weight="balanced" if cw else None, random_state=seed, n_jobs=1
        )
    return HistGradientBoostingClassifier(
        **params, class_weight="balanced" if cw else None, random_state=seed
    )


def fit_pipeline(kind, params, strategy, X_tr, y_tr, seed=42) -> Pipeline:
    """Chuẩn hóa (fit trên train gốc) -> resample -> fit mô hình. Trả về Pipeline(scaler, clf)
    đã fit, nên khi dự đoán chỉ cần pipe.predict_proba(X_thô)."""
    scaler = StandardScaler().fit(X_tr)
    Xs, ys = resample(scaler.transform(X_tr), y_tr, strategy, seed)
    clf = make_estimator(kind, params, strategy, ys, seed).fit(Xs, ys)
    return Pipeline([("scaler", scaler), ("clf", clf)])


# ----------------------------------------------------------------------------
# 4. ĐO ĐẠC
# ----------------------------------------------------------------------------
def _div(a, b):
    return float(a) / float(b) if b else 0.0


def evaluate(y_true, proba, threshold: float = 0.5) -> dict:
    """Accuracy, Precision, Recall (TPR), F1, FPR, ROC-AUC, ma trận nhầm lẫn."""
    y_true = np.asarray(y_true).astype(int)
    proba = np.asarray(proba, float)
    pred = (proba >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
    precision, recall = _div(tp, tp + fp), _div(tp, tp + fn)
    try:
        auc = float(roc_auc_score(y_true, proba)) if len(np.unique(y_true)) == 2 else float("nan")
    except ValueError:
        auc = float("nan")
    return {
        "threshold": float(threshold),
        "accuracy": _div(tp + tn, len(y_true)),
        "precision": precision,
        "recall": recall,
        "f1": _div(2 * precision * recall, precision + recall),
        "fpr": _div(fp, fp + tn),
        "fnr": _div(fn, fn + tp),
        "roc_auc": auc,
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
        "n": int(len(y_true)),
    }


def choose_threshold(y_true, proba, target_fpr: float = 0.01) -> float:
    """Ngưỡng cho Recall cao nhất mà FPR <= target_fpr (bảo mật: báo nhầm file sạch rất phiền)."""
    y_true, proba = np.asarray(y_true).astype(int), np.asarray(proba, float)
    n_neg = max(int((y_true == 0).sum()), 1)
    best_t, best_rec, best_fpr = None, -1.0, 2.0
    for t in np.unique(np.concatenate([proba, [0.5]])):
        pred = proba >= t
        fpr = float(((pred) & (y_true == 0)).sum()) / n_neg
        if fpr <= target_fpr:
            rec = float(((pred) & (y_true == 1)).sum()) / max(int((y_true == 1).sum()), 1)
            if rec > best_rec or (rec == best_rec and t > (best_t or 0)):
                best_t, best_rec, best_fpr = float(t), rec, fpr
    return best_t if best_t is not None else 0.5


def _score(m: dict, scoring: str) -> float:
    if scoring == "balanced":  # Recall cao nhưng phạt FPR
        return m["recall"] - 2.0 * m["fpr"]
    return m[scoring]


# ----------------------------------------------------------------------------
# 5. TUNING (random search, resample trong từng fold)
# ----------------------------------------------------------------------------
def _cv_splits(y, cv, seed):
    y = np.asarray(y)
    cv = max(2, min(cv, int(np.bincount(y).min())))  # không để fold rỗng lớp thiểu số
    return list(StratifiedKFold(cv, shuffle=True, random_state=seed).split(np.zeros(len(y)), y))


def cv_oof_proba(kind, params, strategy, X, y, cv=5, seed=42) -> np.ndarray:
    X, y = np.asarray(X, float), np.asarray(y)
    oof = np.zeros(len(y))
    for tr, va in _cv_splits(y, cv, seed):
        pipe = fit_pipeline(kind, params, strategy, X[tr], y[tr], seed)
        oof[va] = pipe.predict_proba(X[va])[:, 1]
    return oof


def tune(kind, strategy, X, y, n_iter=20, cv=5, scoring="f1", seed=42, verbose=False):
    """Random search. Điểm mỗi bộ tham số = chỉ số `scoring` trên dự đoán out-of-fold (ngưỡng 0.5)."""
    X, y = np.asarray(X, float), np.asarray(y)
    space = param_space(kind)
    total = int(np.prod([len(v) for v in space.values()]))
    cands = list(ParameterSampler(space, n_iter=min(n_iter, total), random_state=seed))
    best = (-np.inf, None, None)
    rows = []
    for i, p in enumerate(cands):
        oof = cv_oof_proba(kind, p, strategy, X, y, cv, seed)
        m = evaluate(y, oof, 0.5)
        s = _score(m, scoring)
        rows.append({**p, "cv_score": s, "cv_recall": m["recall"], "cv_fpr": m["fpr"], "cv_f1": m["f1"]})
        if verbose:
            print(f"   [{i + 1}/{len(cands)}] {scoring}={s:.4f}  {p}")
        if s > best[0]:
            best = (s, p, oof)
    return best[1], best[0], pd.DataFrame(rows).sort_values("cv_score", ascending=False)


# ----------------------------------------------------------------------------
# 6. SO SÁNH CÁC CÁCH XỬ LÝ MẤT CÂN BẰNG
# ----------------------------------------------------------------------------
def compare_strategies(kind, X_tr, y_tr, X_te, y_te, strategies=STRATEGIES, cv=5, seed=42, target_fpr=0.01):
    """Mỗi strategy: dùng tham số mặc định hợp lý, đo CV-OOF trên train và Test độc lập."""
    X_tr, y_tr = np.asarray(X_tr, float), np.asarray(y_tr)
    default = {k: v[len(v) // 2] for k, v in param_space(kind).items()}
    rows = []
    for st in strategies:
        oof = cv_oof_proba(kind, default, st, X_tr, y_tr, cv, seed)
        thr = choose_threshold(y_tr, oof, target_fpr)
        pipe = fit_pipeline(kind, default, st, X_tr, y_tr, seed)
        m = evaluate(y_te, pipe.predict_proba(np.asarray(X_te, float))[:, 1], thr)
        rows.append({"strategy": st, "cv_f1": evaluate(y_tr, oof, 0.5)["f1"], **{f"test_{k}": m[k] for k in
                     ("accuracy", "precision", "recall", "f1", "fpr", "roc_auc", "threshold")}})
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------
# 7. PIPELINE CHÍNH
# ----------------------------------------------------------------------------
def run_pipeline(
    csv_paths: Union[str, Sequence[str]],
    out_dir: str = ".",
    strategy: str = "auto",
    model: str = "auto",
    n_iter: int = 20,
    cv: int = 5,
    target_fpr: float = 0.01,
    scoring: str = "f1",
    test_size: float = 0.2,
    seed: int = 42,
    save: bool = True,
    plots: bool = True,
    verbose: bool = True,
) -> dict:
    """Chạy toàn bộ phần việc của Bạn 6 và trả về dict kết quả."""
    log = print if verbose else (lambda *a, **k: None)
    X, y, names = load_dataset(csv_paths)
    kind = resolve_model(model)
    feats = list(X.columns)
    log(f"[1/5] Dữ liệu: {len(y)} mẫu, {len(feats)} đặc trưng | sạch={int((y == 0).sum())}, mã độc={int((y == 1).sum())} "
        f"(tỉ lệ độc {y.mean():.1%}) | mô hình: {kind}")

    idx = np.arange(len(y))
    tr, te = train_test_split(idx, test_size=test_size, stratify=y, random_state=seed)
    X_tr, X_te, y_tr, y_te = X.iloc[tr].values, X.iloc[te].values, y.iloc[tr].values, y.iloc[te].values

    log("[2/5] So sánh các cách xử lý mất cân bằng...")
    cmp_df = compare_strategies(kind, X_tr, y_tr, X_te, y_te, cv=cv, seed=seed, target_fpr=target_fpr)
    if strategy == "auto":
        ok = cmp_df[cmp_df.test_fpr.notna()].copy()
        # chọn theo CV (không nhìn Test): dùng cv_f1
        strategy = str(ok.sort_values("cv_f1", ascending=False).iloc[0]["strategy"])
    log(f"      -> chiến lược chọn: {strategy}")

    log(f"[3/5] Tuning siêu tham số ({n_iter} bộ x {cv}-fold, tối ưu '{scoring}')...")
    best_params, best_cv, trials = tune(kind, strategy, X_tr, y_tr, n_iter, cv, scoring, seed)
    log(f"      -> tốt nhất: {best_params}  (cv {scoring}={best_cv:.4f})")

    log(f"[4/5] Chọn ngưỡng sao cho FPR <= {target_fpr:.1%} (trên dự đoán out-of-fold của tập Train)...")
    oof = cv_oof_proba(kind, best_params, strategy, X_tr, y_tr, cv, seed)
    thr = choose_threshold(y_tr, oof, target_fpr)

    log("[5/5] Huấn luyện lần cuối và đo trên tập Test độc lập...")
    pipe = fit_pipeline(kind, best_params, strategy, X_tr, y_tr, seed)
    p_te = pipe.predict_proba(X_te)[:, 1]
    final = evaluate(y_te, p_te, thr)
    at_half = evaluate(y_te, p_te, 0.5)
    base_pipe = fit_pipeline(kind, {k: v[len(v) // 2] for k, v in param_space(kind).items()}, "none", X_tr, y_tr, seed)
    baseline = evaluate(y_te, base_pipe.predict_proba(X_te)[:, 1], 0.5)

    result = {
        "model": kind, "strategy": strategy, "best_params": best_params, "threshold": thr,
        "target_fpr": target_fpr, "scoring": scoring, "features": feats,
        "n_train": int(len(tr)), "n_test": int(len(te)),
        "class_counts": {"clean": int((y == 0).sum()), "malware": int((y == 1).sum())},
        "metrics_final": final, "metrics_at_0.5": at_half, "metrics_baseline_no_tuning": baseline,
        "strategy_comparison": cmp_df.to_dict("records"),
        "xgboost_available": HAS_XGB,
    }

    if save:
        paths = _save_outputs(result, pipe, trials, cmp_df, y_te, p_te, out_dir, plots)
        result["saved"] = paths
        for k, v in paths.items():
            log(f"      đã lưu {k}: {v}")
    return result


# ----------------------------------------------------------------------------
# 8. LƯU / NẠP / DỰ ĐOÁN (cho Bạn 1 tích hợp)
# ----------------------------------------------------------------------------
def _save_outputs(result, pipe, trials, cmp_df, y_te, p_te, out_dir, plots) -> dict:
    mdir, rdir = os.path.join(out_dir, "models"), os.path.join(out_dir, "reports")
    os.makedirs(mdir, exist_ok=True)
    os.makedirs(rdir, exist_ok=True)
    paths = {}
    bundle = {"pipeline": pipe, "threshold": result["threshold"], "features": result["features"],
              "model": result["model"], "strategy": result["strategy"], "label_map": {0: "Clean", 1: "Malware"}}
    paths["model"] = os.path.join(mdir, "ban6_best_model.joblib")
    joblib.dump(bundle, paths["model"])
    paths["metrics_json"] = os.path.join(rdir, "ban6_metrics.json")
    with open(paths["metrics_json"], "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2, default=float)
    paths["strategy_csv"] = os.path.join(rdir, "ban6_strategy_comparison.csv")
    cmp_df.to_csv(paths["strategy_csv"], index=False)
    paths["tuning_csv"] = os.path.join(rdir, "ban6_tuning_trials.csv")
    trials.to_csv(paths["tuning_csv"], index=False)
    paths["report_md"] = os.path.join(rdir, "ban6_report.md")
    with open(paths["report_md"], "w", encoding="utf-8") as f:
        f.write(make_markdown_report(result, cmp_df))
    if plots:
        try:
            paths["plot"] = _plot(result, cmp_df, y_te, p_te, os.path.join(rdir, "ban6_evaluation.png"))
        except Exception as e:  # pragma: no cover
            warnings.warn(f"Không vẽ được biểu đồ: {e}")
    return paths


def load_bundle(path: str) -> dict:
    b = joblib.load(path)
    if not isinstance(b, dict) or "pipeline" not in b:
        raise ValueError("File không phải bundle của Bạn 6")
    return b


def predict_bundle(bundle: dict, features: Union[pd.DataFrame, dict]) -> pd.DataFrame:
    """Nhận bảng đặc trưng (có thể thừa/thiếu cột - thiếu tự điền 0) -> proba + nhãn theo ngưỡng đã tối ưu."""
    if isinstance(features, dict):
        features = pd.DataFrame([features])
    X = features.reindex(columns=bundle["features"]).apply(pd.to_numeric, errors="coerce").fillna(0.0)
    p = bundle["pipeline"].predict_proba(X.values)[:, 1]
    pred = (p >= bundle["threshold"]).astype(int)
    return pd.DataFrame({"proba_malware": p, "prediction": pred,
                         "verdict": [bundle["label_map"][int(v)] for v in pred]}, index=features.index)


# ----------------------------------------------------------------------------
# 9. BÁO CÁO
# ----------------------------------------------------------------------------
def make_markdown_report(r: dict, cmp_df: pd.DataFrame) -> str:
    m, b, h = r["metrics_final"], r["metrics_baseline_no_tuning"], r["metrics_at_0.5"]
    pct = lambda v: f"{v * 100:.2f}%"
    L = [
        "# Kết quả tối ưu mô hình & đánh giá (Bạn 6)", "",
        f"- Mô hình: **{r['model']}**  |  Xử lý mất cân bằng: **{r['strategy']}**",
        f"- Dữ liệu: {r['class_counts']['clean']} sạch / {r['class_counts']['malware']} mã độc; "
        f"Train {r['n_train']} - Test {r['n_test']} (phân tầng 80:20)",
        f"- Tham số tốt nhất: `{r['best_params']}`",
        f"- Ngưỡng quyết định: **{m['threshold']:.4f}** (ràng buộc FPR <= {pct(r['target_fpr'])})", "",
        "## Bảng chỉ số trên tập Test độc lập", "",
        "| Cấu hình | Accuracy | Precision | Recall | F1 | **FPR** | ROC-AUC |", "|---|---|---|---|---|---|---|",
    ]
    for name, x in (("Baseline (chưa xử lý mất cân bằng, chưa tuning)", b),
                    ("Sau tối ưu, ngưỡng 0.5", h), (f"Sau tối ưu, ngưỡng {m['threshold']:.3f}", m)):
        L.append(f"| {name} | {pct(x['accuracy'])} | {pct(x['precision'])} | {pct(x['recall'])} | "
                 f"{pct(x['f1'])} | **{pct(x['fpr'])}** | {x['roc_auc']:.4f} |")
    L += ["", f"Ma trận nhầm lẫn (Test): TN={m['tn']}, FP={m['fp']}, FN={m['fn']}, TP={m['tp']}.",
          f"FPR = FP / (FP + TN) = {m['fp']}/{m['fp'] + m['tn']} = {pct(m['fpr'])}: tỉ lệ file sạch bị báo nhầm là mã độc.", "",
          "## So sánh các cách xử lý mất cân bằng lớp", "",
          "| Chiến lược | Accuracy | Recall | FPR | F1 | ROC-AUC |", "|---|---|---|---|---|---|"]
    for _, row in cmp_df.iterrows():
        L.append(f"| {row['strategy']} | {pct(row['test_accuracy'])} | {pct(row['test_recall'])} | "
                 f"{pct(row['test_fpr'])} | {pct(row['test_f1'])} | {row['test_roc_auc']:.4f} |")
    if not r.get("xgboost_available"):
        L += ["", "> Ghi chú: máy chạy chưa cài xgboost nên dùng mô hình thay thế cùng họ Gradient Boosting."]
    return "\n".join(L) + "\n"


def _plot(r, cmp_df, y_te, p_te, path):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    m = r["metrics_final"]
    fig, ax = plt.subplots(1, 3, figsize=(16, 4.6))
    fpr, tpr, _ = roc_curve(y_te, p_te)
    ax[0].plot(fpr, tpr, lw=2, label=f"AUC={m['roc_auc']:.3f}")
    ax[0].plot([0, 1], [0, 1], "--", c="gray")
    ax[0].scatter([m["fpr"]], [m["recall"]], c="red", zorder=5, label=f"Ngưỡng {m['threshold']:.2f}")
    ax[0].set(xlabel="FPR", ylabel="Recall (TPR)", title="Đường ROC")
    ax[0].legend()
    cm = np.array([[m["tn"], m["fp"]], [m["fn"], m["tp"]]])
    ax[1].imshow(cm, cmap="Blues")
    for (i, j), v in np.ndenumerate(cm):
        ax[1].text(j, i, str(v), ha="center", va="center", fontsize=16,
                   color="white" if v > cm.max() / 2 else "black")
    ax[1].set(xticks=[0, 1], yticks=[0, 1], xticklabels=["Dự đoán sạch", "Dự đoán độc"],
              yticklabels=["Thực sạch", "Thực độc"], title="Ma trận nhầm lẫn (Test)")
    x = np.arange(len(cmp_df))
    ax[2].bar(x - 0.2, cmp_df["test_recall"], 0.4, label="Recall")
    ax[2].bar(x + 0.2, cmp_df["test_fpr"], 0.4, label="FPR", color="tab:red")
    ax[2].set(xticks=x, xticklabels=cmp_df["strategy"], title="So sánh xử lý mất cân bằng", ylim=(0, 1.05))
    ax[2].tick_params(axis="x", rotation=20)
    ax[2].legend()
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)
    return path


# ----------------------------------------------------------------------------
# CLI:  python -m modules.model_optimizer --csv data.csv
# ----------------------------------------------------------------------------
def main(argv: Optional[Iterable[str]] = None):
    import argparse

    ap = argparse.ArgumentParser(description="Bạn 6: tối ưu mô hình & đánh giá (Recall / FPR)")
    ap.add_argument("--csv", nargs="+", required=True, help="1 hoặc nhiều CSV (ghép theo cột filename)")
    ap.add_argument("--out", default=".", help="Thư mục gốc để tạo models/ và reports/")
    ap.add_argument("--strategy", default="auto", choices=("auto",) + STRATEGIES)
    ap.add_argument("--model", default="auto", choices=("auto", "xgboost", "random_forest", "hist_gb"))
    ap.add_argument("--n-iter", type=int, default=20)
    ap.add_argument("--cv", type=int, default=5)
    ap.add_argument("--target-fpr", type=float, default=0.01)
    ap.add_argument("--scoring", default="f1", choices=("f1", "recall", "roc_auc", "balanced"))
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args(list(argv) if argv is not None else None)
    run_pipeline(a.csv, a.out, a.strategy, a.model, a.n_iter, a.cv, a.target_fpr, a.scoring, seed=a.seed)


if __name__ == "__main__":
    main()
