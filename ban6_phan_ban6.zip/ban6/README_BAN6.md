# Phần Bạn 6 – Tối ưu mô hình & đánh giá

## Gộp vào repo malware-static-main (chỉ THÊM file, không sửa file của ai)
Chép các mục sau vào thư mục gốc repo:
- `modules/model_optimizer.py`   ← file chính (đặt cạnh pe_extractor.py, ngram_extractor.py...)
- `tools/make_fake_dataset.py`, `tests/test_ban6.py`, `run_ban6_demo.py`, `README_BAN6.md`
- Không ghi đè `modules/__init__.py` của repo (file này đang rỗng, không cần sửa).
- Thêm vào requirements.txt (nếu thiếu): `matplotlib`. (xgboost là tùy chọn; chưa có thì tự dùng HistGradientBoosting.)

## Test nhanh (dữ liệu giả, ~10 giây)
    python tests/test_ban6.py        # 11 test
    python run_ban6_demo.py          # sinh dữ liệu giả lệch 92/8, chạy toàn bộ, in kết quả
    python tools/make_fake_dataset.py --malware-ratio 0.05 --difficulty 2 --out data/hard.csv
    python run_ban6_demo.py --csv data/hard.csv

## Khi có dữ liệu thật
    python run_ban6_demo.py --csv dataset_pe.csv                       # Bạn 2
    python run_ban6_demo.py --csv dataset_pe.csv dataset_ngram_features.csv   # ghép theo cột filename
CSV cần cột `label` (0 sạch / 1 độc, hoặc chữ clean/malware); cột filename/md5... tự bị bỏ khỏi đặc trưng.

## Đầu ra
- `models/ban6_best_model.joblib`  (pipeline + ngưỡng + danh sách đặc trưng)
- `reports/ban6_report.md` (bảng dán thẳng vào Word), `ban6_metrics.json`, `ban6_evaluation.png`, `ban6_strategy_comparison.csv`, `ban6_tuning_trials.csv`

## Cho Bạn 1 gọi trong main.py / app.py
    from modules.model_optimizer import load_bundle, predict_bundle
    bundle = load_bundle("models/ban6_best_model.joblib")
    out = predict_bundle(bundle, features_dict_or_df)   # proba_malware, prediction, verdict
